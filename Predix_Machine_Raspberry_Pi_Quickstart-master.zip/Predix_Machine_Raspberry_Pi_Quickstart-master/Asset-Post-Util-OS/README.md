# Asset-Post-Util GO Application
This directory is holds the various binaries of the Asset-Post-Util GO application found in the repository below:
https://github.build.ge.com/SDLP-Predix-Project/Asset-Post-Util

### Purpose
The main responsibility of this application is to post data to an instance of Predix Asset
