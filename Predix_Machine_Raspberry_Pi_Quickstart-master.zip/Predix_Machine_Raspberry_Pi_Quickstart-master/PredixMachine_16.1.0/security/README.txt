
Security - this folder should be locked down to only the administrator
=====================================================================

This folder contains configuration of virtual machine properties and security fields.

com.ge.dspmicro.securityadmin.cfg - Configuration properties for the Predix Machine securityadmin service and Felix HTTP Service

machine_keystore.jceks - example keystore used for signing and SSL

machine_truststore.jks - example trust store.

machinegateway_truststore.jks - example trust store for machine adapters.

