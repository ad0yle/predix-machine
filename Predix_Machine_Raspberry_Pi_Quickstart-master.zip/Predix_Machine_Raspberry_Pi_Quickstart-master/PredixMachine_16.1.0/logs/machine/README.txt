
All machine application logs will be placed here.