# Temp App
This application has no functional purpose other than providing the ability to quickly instantiate, configure, and get properties of Predix Services. After finishing setting up the desired Predix Services and passing their properties to the `app-front-end` app,  the Temp App is deleted and the actual application is then pushed and bound to the Services instantiated.
